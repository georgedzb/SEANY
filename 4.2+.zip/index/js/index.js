var vara = 0
var at=new Date('2022-2-24');
var bt=new Date();
var ct=(bt-at)/(1000*60*60*24) + 1;
var dt = Math.floor(ct);
function ap(){
	document.getElementById("body").removeAttribute("hidden");
	document.getElementById("ad").hidden = "hidden";
}
setTimeout("ap();",3000);
function aa(){
	if (typeof(Storage) !== "undefined")
	{var p = window.prompt("输入你的搜索引擎（LocalStorage保存，下次仍可使用）（例如https://www.baidu.com/s?wd=）"); localStorage.setItem("ljs",p);}
	else
	{document.getElementById("result").innerHTML = "抱歉！您的浏览器不支持 Web Storage ...";}
}
var so = "https://www.baidu.com/s?wd=";
function baidu(){so = "https://www.baidu.com/s?wd="};
function tst(){so = "https://www.so.com/s?q="};
function chinaso(){so = "http://www.chinaso.com/newssearch/all/allResults?q="};
function sogou(){so = "https://www.sogou.com/web?query="};
function bingcn(){so = "https://cn.bing.com/search?ensearch=0&q="};
function yandex(){so = "https://yandex.com/search/?text="};
function bingen(){so = "https://cn.bing.com/search?ensearch=1&q="};
function zdyso(){so = localStorage.getItem("ljs");};
function google(){so = "https://www.google.com/search?q="};
function yahoo(){so = "https://search.yahoo.com/search?p="};
function sea(){
	if (document.getElementById("text").value == "" || null)
	{window.alert("请输入内容！");window.open("https://www.baidu.com/s?ie=UTF-8&wd=%E4%BF%84%E7%BD%97%E6%96%AF%E4%B9%8C%E5%85%8B%E5%85%B0%E5%B1%80%E5%8A%BF");}
	else
	{
	var obj = document.getElementById("sel");
	var index = obj.selectedIndex;
	var t = obj.options[index].text;
	if (t == "百度")
	{baidu();}
	else if (t == "360")
	{tst();}
	else if (t == "国搜")
	{chinaso();}
	else if (t == "搜狗")
	{sogou();}
	else if (t == "必应")
	{bingcn();}
	else if (t == "Yandex(RU)")
	{yandex();}
	else if (t == "必应国际(US)")
	{bingen();}
	else if (t == "自定义搜索")
	{zdyso();}
	else if (t == "Google(US)")
	{google();}
	else if (t == "Yahoo(US)")
	{yahoo();}
	else 
	{};
	var sox = document.getElementById("text").value;
	var patt = new RegExp("://");
	var patts = patt.test(sox);
	if (patts == true)
	{window.open(sox , "_blank");}
	else
	{var sos = so + sox; window.open(sos , "_blank");}
	}
}
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?e37d86ded4b682e76bd440a5f7e18193";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
function qrclickon(){
	vara = 1;
	document.getElementById("qrnote").removeAttribute("hidden");
}
function qrclickdown(){
	vara = 0;
	document.getElementById("qrnote").hidden = "hidden";
}