function down(){
	document.getElementById("button").removeAttribute("hidden");
}
function sea(){
	var text = document.getElementById("text").value;
	var texta = "https://www.baidu.com/s?wd=" + text;
	window.location = texta;
}